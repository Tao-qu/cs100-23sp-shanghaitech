#include "sum.hpp"

int sum(int a, int b) {
  return a + b;
}