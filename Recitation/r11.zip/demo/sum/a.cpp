#include "sum.hpp"

#include <iostream>

int main() {
  int a, b;
  std::cin >> a >> b;
  std::cout << sum(a, b) << std::endl;
  return 0;
}