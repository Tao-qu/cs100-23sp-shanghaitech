#ifndef SUM_HPP
#define SUM_HPP

int sum(int a, int b);

#endif // SUM_HPP