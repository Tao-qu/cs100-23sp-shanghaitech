void foo(int x) {
  auto y = x;
  x = y;
}