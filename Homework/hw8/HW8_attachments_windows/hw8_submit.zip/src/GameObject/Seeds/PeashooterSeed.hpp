#ifndef PEASHOOTERSEED_HPP__
#define PEASHOOTERSEED_HPP__

#include "Seeds.hpp"

class PeashooterSeed : public Seeds
{
public:
    PeashooterSeed(pGameWorld CurrentWorld);

private:
};

#endif // !PEASHOOTERSEED_HPP__