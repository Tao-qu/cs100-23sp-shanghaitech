#ifndef CHERRYBOMBSEED_HPP__
#define CHERRYBOMBSEED_HPP__

#include "Seeds.hpp"

class CherryBombSeed : public Seeds
{
public:
    CherryBombSeed(pGameWorld CurrentWorld);

private:
};

#endif // !CHERRYBOMBSEED_HPP__