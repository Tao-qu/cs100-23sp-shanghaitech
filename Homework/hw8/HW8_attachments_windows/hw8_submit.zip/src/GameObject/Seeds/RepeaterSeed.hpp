#ifndef REPEATERSEED_HPP__
#define REPEATERSEED_HPP__

#include "Seeds.hpp"

class RepeaterSeed : public Seeds
{
public:
    RepeaterSeed(pGameWorld CurrentWorld);

private:
};

#endif // !REPEATERSEED_HPP__