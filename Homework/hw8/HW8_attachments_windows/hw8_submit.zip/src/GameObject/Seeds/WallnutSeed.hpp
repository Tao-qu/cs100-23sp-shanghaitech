#ifndef WALLNUTSEED_HPP__
#define WALLNUTSEED_HPP__

#include "Seeds.hpp"

class WallnutSeed : public Seeds
{
public:
    WallnutSeed(pGameWorld CurrentWorld);

private:
};

#endif // !WALLNUTSEED_HPP__