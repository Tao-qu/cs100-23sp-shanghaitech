#ifndef SUNFLOWERSEED_HPP__
#define SUNFLOWERSEED_HPP__

#include "Seeds.hpp"

class SunflowerSeed : public Seeds
{
public:
    SunflowerSeed(pGameWorld CurrentWorld);

private:
};

#endif // !SUNFLOWERSEED_HPP__