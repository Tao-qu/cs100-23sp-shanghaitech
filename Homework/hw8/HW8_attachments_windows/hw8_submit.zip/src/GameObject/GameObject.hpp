#ifndef GAMEOBJECT_HPP__
#define GAMEOBJECT_HPP__

#include <memory>
#include <list>
#include "ObjectBase.hpp"

// Declares the class name GameWorld so that its pointers can be used.
class GameWorld;
using pGameWorld = std::shared_ptr<GameWorld>;

enum class UIName
{
  SunflowerSeed,
  PeashooterSeed,
  WallnutSeed,
  CherryBombSeed,
  RepeaterSeed,
  Shovel,
  None
};

using HP = int;

const HP HP_SUNFLOWER = 300;
const HP HP_PEASHOOTER = 300;
const HP HP_WALLNUT = 4000;
const HP HP_CHERRY_BOMB = 4000;
const HP HP_REPEATER = 300;
const HP HP_REGULAR_ZOMBIE = 200;
const HP HP_Bucket_Head_Zombie = 1300;
const HP HP_Pole_Vaulting_Zombie = 340;
const HP HP_IMMORTAL = 999999;

using ATK = int;

const ATK ATK_NONE = 0;
const ATK ATK_IMMEDIATE_DEATH = 999999;
const ATK ATK_PEASHOOTER = 20;
const ATK ATK_REPEATER = 20;
const ATK ATK_REGULAR_ZOMBIE = 3;
const ATK ATK_BUCKET_HEAD_ZOMBIE = 3;
const ATK ATK_POLE_VAULTING_ZOMBIE = 3;

using CD = int;

const CD CD_SUNFLOWER_SEED = 240;
const CD CD_PEASHOOTER_SEED = 240;
const CD CD_WALLNUT_SEED = 900;
const CD CD_CHERRY_BOMB_SEED = 1200;
const CD CD_REPEATER_SEED = 240;

const CD CD_SUNFLOWER = 600;
const CD CD_PEASHOOTER = 30;
const CD CD_WALLNUT = 0;
const CD CD_CHERRY_BOMB = 15;
const CD CD_REPEATER = 30;

class GameObject : public ObjectBase, public std::enable_shared_from_this<GameObject>
{
public:
  using std::enable_shared_from_this<GameObject>::shared_from_this; // Use shared_from_this() instead of "this".

  GameObject(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID, HP hp, ATK atk, pGameWorld CurrentWorld);

  bool IsDead();
  virtual bool IsPlant();
  virtual bool IsProjectile();
  virtual bool IsZombie();

  HP GetHP();
  ATK GetATK();
  pGameWorld GetCurrentWorld();

  void SetHP(HP hp);
  void SetATK(ATK atk);
  virtual void Collide(std::shared_ptr<GameObject> object);
  virtual void Update() override;
  virtual void OnClick() override;

private:
  HP m_HP;
  ATK m_ATK;
  pGameWorld m_CurrentWorld;
};

#endif // !GAMEOBJECT_HPP__
